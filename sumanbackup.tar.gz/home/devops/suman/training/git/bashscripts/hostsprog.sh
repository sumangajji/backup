#!/bin/hosts
for ip in `cat hosts`;do
echo "**************"
echo "$ip"
done
