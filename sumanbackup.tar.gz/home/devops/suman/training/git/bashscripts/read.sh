read varname

echo "you have entered $varname"
