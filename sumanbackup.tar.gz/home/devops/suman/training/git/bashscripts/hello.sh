#!/bin/bash

echo "Heloo LaxmiKanth"

a=1
b="This is String"
c=1.2

echo "Value of a is $a"
echo "Value of a is $b"
echo "Value of a is $c"
echo "The End"
