#!/bin/bash

#script to copy file 

cp $1 $2

#checking the file is coped or not

ls -al $2

#poweroff
#./copy.sh hello.sh /tmp
