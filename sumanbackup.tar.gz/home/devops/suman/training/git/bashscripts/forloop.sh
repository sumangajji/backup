#!/bin/bash

for files in *
do
bash "$files"
echo "############"
done


