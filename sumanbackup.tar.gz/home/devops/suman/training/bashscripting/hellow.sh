#!/bin/bash
#the fallowing to print 
echo 'Hellow Devops'
a=1
b='This is a string.'
c=1.2
echo "value of a is $a"
echo "value of b is $b"
echo value of c is $c
echo '########################'
echo $0
echo $1
echo $2
echo "number of arguments in the script $#"
echo "arguments in the script are $@"


#to copy some files
cp $1 $2

#to print for confirmation
ls -lh $2 
