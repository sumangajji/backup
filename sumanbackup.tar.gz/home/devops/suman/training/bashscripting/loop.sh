#!/bin/bash
for int in 1 3
do 
  echo $int
done


