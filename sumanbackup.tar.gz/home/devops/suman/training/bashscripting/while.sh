#!/bin/bash 
read -p package

